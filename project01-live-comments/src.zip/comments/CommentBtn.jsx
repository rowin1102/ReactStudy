export default function CommentBtn(props) {
  return (<>
    {/* 댓글 작성 버튼 */}
    <button className="btn btn-primary" data-bs-toggle="modal" data-bs-target="#commentModal">
        댓글 작성
    </button>
  </>); 
}